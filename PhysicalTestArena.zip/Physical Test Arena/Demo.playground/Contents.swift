import Physical
import Foundation

Physical.Globals.shared.sigfigs = 5

// BASIC IDEA: EXTENDING NUMBERS

let distance1 = 10.5.centimeters
let distance2 =  3.3.feet

distance1 + distance2

let speed = 42.0.kilometersPerHour

distance2 / speed
(distance2 / speed).to(.hours)
distance2 / speed → .milliseconds

// CHAINING UNITS

let aForce = 1.kilograms.meters.seconds(-2)
aForce → .newtons

6.meters.seconds(-1)
6.meters/.seconds

12.meters/.seconds/.seconds


Physical.Globals.shared.sigfigs = nil


let radius = 60.45.kilometers
let area = Double.pi * (radius^2) → .squareFeet
let volume = (4.π / 3) * (radius^3)

volume.value
volume.sigfigs

var distance = 4.meters
distance.sigfigs
distance / 3

distance = 4.meters.sigfigs(5)
distance.sigfigs
distance / 3

(distance / 3).significantValue


Physical.Globals.shared.sigfigs = 5


// VARIOUS EXPRESSIONS

var density = 27.grams.centimeters(-3)
density = 27.grams.cubicCentimeters(-1)
density = 27.g.cm(-3)
density = 27.g/.cm(3)
density = 27.grams.perCubicCentimeter

density → .milligramsPerDeciliter
density → .gramsPerLiter


// MIXING DIMENSIONS

let force = 4.5.newtons
let mass = 17.poundsMass

force + mass
(force + mass) / 7.feet

force.dimensionalDescription
mass.dimensionalDescription

let acceleration = force / mass
acceleration → .gravity

acceleration ~ 1.gravity

1.gravity.withBasicUnits
force.withBasicUnits

mass * acceleration
mass * acceleration → .newtons
mass * acceleration → .joules
mass * acceleration * 37.feet → .joules

(mass * acceleration).errorStack


// ANOTHER MIXING EXAMPLE

let time = 4.seconds
let angle = 2.revolutions

angle / time
angle → .radians
(angle → .degrees) / time


// ANGLES AND TRIG

75°
sin(75°)
asin(sin(75°))
75° → .radians
asin(sin(75°)) → .degrees


let θ₀ = (2.π/5).radians
let θ₁ = θ₀ → .degrees
let θ₂ = θ₀ → .revolutions

sin(θ₀)
sin(θ₁)
sin(θ₂)


// ARRAYS, RAMPS and INDEXES

let fileSizes = [1, 3, 14, -2].gigabytes
let dataRate = 1.megabits.perSecond

(fileSizes / dataRate → .hours)


ramp(in: 0...1.pi, count: 27)

let angles = ramp(in: 0...1.pi, count: 27).radians.sigfigs(3)
angles[26]
sin(angles)[26]
asin(sin(angles))


// UNIT EXPONENTS

let x = 4.76.meters

x ^ 5
(x ^ 5) ^ 0.2
(x ^ 5) ^ 0.2 → .yards

let y = x ^ (3.0 / 7)

y ^ 7
y ^ 7 → .cubicInches

x ^ π
(x ^ π) ^ (1/π)
(x ^ π) ^ (1/π) → .yards


// NEW WAYS TO USE OLD APIS
/*
 sleep(2)
 usleep(30_000)
 
 func sleep(_ t: Physical) {
 if t ~ 1.s {
 usleep(UInt32(round((t → .microseconds).value)))
 }
 }
 
 sleep(30.milliseconds)
 */

Physical.Globals.shared.sigfigs = nil

// STRONG TYPING:

Length(45.feet)
Length(45.hectares)

Int("test")

//Length(45, unit: .hectares)
let sailHeight = Length(45, unit: .feet)
sailHeight.physical


let G = Physical.Constants.gravitation
let sunMass = Physical.Constants.Astronomic.Sun.mass
let earthMass = Physical.Constants.Earth.mass
let earthRadius = Physical.Constants.Earth.meanRadius

func orbitHeight(period: Duration) -> Length {
	return Length( ∛(G * earthMass * (period^2) / 4.π²) - earthRadius )!
}

let heightISS = orbitHeight(period: Duration(92, unit: .minutes)).physical
heightISS → .miles

func orbitalPeriod(height: Length) -> Duration {
	Duration( √(4.π² * ((heightISS + earthRadius)^3) / (G * earthMass)) )!
}

let periodISS = orbitalPeriod(height: Length(254, unit: .miles)).physical
periodISS → .minutes
